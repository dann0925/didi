# Open modal

Open kepler.gl in a modal

### Local dev
```
npm install
```
or
```
yarn --ignore-engines
```

add mapbox access token to node env
```
export MapboxAccessToken=<your_mapbox_token>
```

then
```
npm start
```
