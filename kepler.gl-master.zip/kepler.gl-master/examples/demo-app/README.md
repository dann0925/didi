# Demo App

This is the src code of kepler.gl demo app.


### Local dev
```
npm install
```
or
```
yarn --ignore-engines
```

add mapbox access token to node env
```
export MapboxAccessToken=<your_mapbox_token>
```

then
```
npm start
```
