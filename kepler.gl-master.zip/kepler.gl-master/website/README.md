This is the source code of the demo website for kepler.gl.

## Developing

    npm install // or yarn --ignore-engies
    export MapboxAccessToken=<insert_your_token> && npm start
