# Cluster

![Cluster layer](https://d1a3f4spazzrp4.cloudfront.net/kepler.gl/documentation/image46.png "Cluster layer")

Cluster layers visualize aggregated data based on a geospatial radius.

[Back to table of contents](../a-introduction.md)
