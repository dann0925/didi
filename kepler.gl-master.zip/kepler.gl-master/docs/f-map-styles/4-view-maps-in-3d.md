# View Maps in 3D
View your map in 3D by clicking the 3D icon in the top right corner of your map:

![View Maps in 3D](https://d1a3f4spazzrp4.cloudfront.net/kepler.gl/documentation/image4.png "View Maps in 3D")

[Back to table of contents](../a-introduction.md)
